package config
/*import (
	"../LineThrift"
)*/

/* server */

var IPCOK = ""
var KURA = "https://legy-jp-addr-short.line.naver.jp"
var HANI = "https://legy-jp-addr-short.line.naver.jp"
var RINJANI = "https://legy-gslb.line.naver.jp"
var LINE_HOST_DOMAIN = KURA
var LINE_OBS_DOMAIN = "https://obs.line-apps.com"
var LINE_TIMELINE_API = KURA+"/mh/api"
var LINE_TIMELINE_MH = KURA+"/mh"

var LINE_LOGIN_QUERY_PATH = "/api/v4p/rs"
var LINE_AUTH_QUERY_PATH = "/api/v4/TalkService.do"

var LINE_API_QUERY_PATH_FIR = "/S4"
var LINE_POLL_QUERY_PATH_FIR = "/P4"
var LINE_CALL_QUERY_PATH = "/V4"
var LINE_CERTIFICATE_PATH = "/Q"
var LINE_CHAN_QUERY_PATH = "/CH4"
var LINE_SQUARE_QUERY_PATH = "/SQS1"
var LINE_POLL_QUERY_PATH_THI = "/F4"

var APP_TYPE = "CHANNELCP"//func (ap LineThrift.ApplicationType) (string) { return ap.String() } (32)
var APP_VER string = ""
var CARRIER = "51010"
var SYSTEM_NAME = "Android OS"
var SYSTEM_VER = "10"
var VER = "10"
var IP_ADDR string = ""
var LINE_APPLICATION string = ""
var USER_AGENT string = "LLA/2.17.0 Galaxy Note 10 10"
//fmt.Println(LINE_APPLICATION)

var TIMELINE_CHANNEL_ID = "1341209950"
var WEBTOON_CHANNEL_ID = "1401600689"
var TODAY_CHANNEL_ID = "1518712866"
var STORE_CHANNEL_ID = "1376922440"
var MUSIC_CHANNEL_ID = "1381425814"
var SERVICES_CHANNEL_ID = "1459630796"
/* additional stuff */
var AutoCancel = false