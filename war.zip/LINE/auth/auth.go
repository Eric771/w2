package auth

import (
	"../service"
	"../helper"
	"../config"
	"../LineThrift"
	"net/http"
	"fmt"
	"io/ioutil"
	//"time"
	"encoding/json"
	"context"
	// "crypto/rsa"
	// "strconv"
)

type InsideResults struct {
	Verifier string `json:"verifier"`
	AuthPhase string `json:"authPhase"`
}
type Results struct {
	Result InsideResults `json:"result"`
	Timestamp string `json:"timestamp"`
}


func getResult(body []byte) (*Results, error) {
	var s = new(Results)
	err := json.Unmarshal(body, &s)
	return s, err
}

func LoadService(){
	if service.IsLogin != true {
		panic("[Error]Not yet logged in.")
	}
	talk := service.TalkService()
	rep, err := talk.GetLastOpRevision(context.TODO())
	if err != nil {
		panic(err)
	}
	getprof, err := talk.GetProfile(context.TODO())
	if err != nil {
		panic(err)
	}
	service.Revision = rep
	service.MID = getprof.Mid
  ab := `
 ██████╗ ██╗     ██╗  ██╗██████╗ █████╗ ████████╗ ██████╗
██╔════╝ ██║     ╚██╗██╔╝██╔══██╗██╔══██╗╚══██╔══╝██╔════╝
██║  ██╗ ██║      ╚███╔╝ ██████╦╝██║  ██║   ██║   ╚█████╗
██║  ╚██╗██║      ██╔██╗ ██╔══██╗██║  ██║   ██║    ╚═══██╗
╚██████╔╝███████╗██╔╝╚██╗██████╦╝╚█████╔╝   ██║   ██████╔╝
 ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝  ╚════╝    ╚═╝   ╚═════╝`
  abc := "\n\nCreator By E L F O X"
  fmt.Println(string(helper.ColorCyan),ab, string(helper.ColorReset))
  fmt.Println(abc)
	service.IsLogin = true
}

func loginRequestQR(identity LineThrift.IdentityProvider, verifier string) *LineThrift.LoginRequest{
	lreq := &LineThrift.LoginRequest{
		Type: 1,
		KeepLoggedIn: true,
		IdentityProvider: identity,
		AccessLocation: config.IP_ADDR,
		SystemName: config.SYSTEM_NAME,
		Verifier: verifier,
		E2eeVersion: 0,
	}
	return lreq
}

func LoginWithQrCode(keepLoggedIn bool){
	tauth := service.AuthService()
	qrCode, err := tauth.GetAuthQrcode(context.TODO(), keepLoggedIn, config.SYSTEM_NAME, true)
	if err != nil{
		panic(err)
	}

	fmt.Println("line://au/q/"+qrCode.Verifier)
	client := &http.Client{}
	req, _ := http.NewRequest("GET", config.LINE_HOST_DOMAIN+config.LINE_CERTIFICATE_PATH, nil)
	req.Header.Set("User-Agent",config.USER_AGENT)
	req.Header.Set("X-Line-Application",config.LINE_APPLICATION)
	req.Header.Set("X-Line-Access",qrCode.Verifier)
	service.AuthToken = qrCode.Verifier
	res, _ := client.Do(req)
	defer res.Body.Close()
	body, _ := ioutil.ReadAll(res.Body)
	s, _ := getResult([]byte(body))
	iR := s.Result
	_verifier := iR.Verifier

	loginZ := service.LoginZService()
	loginReq := loginRequestQR(1, _verifier)
	resultz, err := loginZ.LoginZ(context.TODO(),loginReq)
	if err != nil {
		panic(err)
	}
	service.IsLogin = true
	LoginWithAuthToken(resultz.AuthToken)
}

func LoginWithAuthToken(authToken string){ 
	service.AuthToken = authToken
	service.IsLogin = true
	headers := make(http.Header)
	headers.Add("X-Line-Application", config.APP_TYPE)
	headers.Add("X-Line-Access", service.AuthToken)
	headers.Add("User-Agent", config.USER_AGENT)
	service.Headers = headers
	LoadService()
}

func LoginWithAuthTokenVH(authToken string){ 
	service.AuthToken = authToken
	service.IsLogin = true
	headers := make(http.Header)
	headers.Add("X-Line-Application", config.APP_TYPE)
	headers.Add("X-Line-Access", service.AuthToken)
	headers.Add("User-Agent", config.USER_AGENT)
	service.Headers = headers
  fmt.Println("SUKSES2")
}